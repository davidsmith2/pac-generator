module.exports = {
    name: String,
    port: String,
    server: String
};