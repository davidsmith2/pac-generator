module.exports = {
    host: String,
    proxy: String,
    active: Boolean
};